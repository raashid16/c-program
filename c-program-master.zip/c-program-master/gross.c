#include<stdio.h>
int main()
{
int sal,HA, DA;
printf(" Enter your salary");
scanf("%d", &sal);
HA = 0.2*sal;
DA = 0.4*sal;
printf(" The HA is %d \n", HA);
printf(" The DA is %d \n", DA);

}

