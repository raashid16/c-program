#include<stdio.h>
float main()
{
float b,h,a;
printf(" Enter the breadth");
scanf("%f", &b);
printf(" Enter the height");
scanf("%f" , &h);
a=0.5*(b*h);
printf(" The area of the triangle is %f ", a);
}
 
