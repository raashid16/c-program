#include<stdio.h>
void main()
{
printf("welcome to c programming \n ");
}
