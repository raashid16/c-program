#include<stdio.h>
float main()
{
float r,A, C;
printf(" Enter the radius of the circle");
scanf("%f", &r);
A = 3.14*r*r;
C = 2*3.14*r;
printf(" The area of the circle is %f \n",A);
printf(" The circumfrence of the circle is %f \n",C);
}  
