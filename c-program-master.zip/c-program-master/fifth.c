#include<stdio.h>
float main()
{
float a,b,c;
printf("enter a  decimal number");
scanf("%f",&a);
printf("enter a decimal number");
scanf("%f",&b);
c=a+b;
printf("the sum is %f =  \n",c);
}
