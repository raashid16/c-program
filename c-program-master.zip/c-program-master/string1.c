#include<stdio.h>
void main()
{
char a[30];
printf(" enter ur name ");
scanf("%s" ,a);
printf(" The name u entered is %s ", a);
}

