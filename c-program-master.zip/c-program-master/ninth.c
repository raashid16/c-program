#include<stdio.h>
int main()
{
int  a,b,c;
printf(" Enter a number A ");
scanf("%d", &a);
printf(" Enter a number B ");
scanf("%d", &b);
c = a%b;
printf("The  modulus c of a and b is =%.2d \n", c);
}  

