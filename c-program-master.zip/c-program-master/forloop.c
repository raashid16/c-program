#include<stdio.h>
int main()
{
int counter;
for(;     ;)
{
printf("%d",counter);
}
}
