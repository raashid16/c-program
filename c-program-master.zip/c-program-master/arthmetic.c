#include<stdio.h>
int main()
{
int a,b,c,d,e,f;
printf(" Enter the value of a and b");
scanf("%d %d", &a,&b);
c = a+b;
d = a-b;
e = a*b;
f = a%b;
printf(" the sum is  %d \n",c);
printf(" the diffrence is  %d\n",d);
printf(" the product is  %d \n ",e);
printf(" the modulus is  %d \n",f);
}
