#include<stdio.h>
float main()
{
float s,a;
printf(" Enter the side");
scanf("%f", &s);
a= s*s;
printf(" The area of the square is %f " ,a);
} 
