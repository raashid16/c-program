#include<stdio.h>
float main()
{
float b,h,a;
printf(" Enter the breadth");
scanf("%f", &b);
printf(" Enter the height");
scanf("%f", &h);
a=b*h;
printf(" The area of the parallelogram is %f " ,a);
}
