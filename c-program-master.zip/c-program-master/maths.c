#include<stdio.h>
float main()
{
float l,b,h,a;
printf(" Enter the length");
scanf("%f", &l);
printf(" Enter the breadth");
scanf("%f", &b);
printf(" Enter the height");
scanf("%f" , &h);
a=(l+b)*h*0.5;
printf(" The area of the trap is %f",a);
}
  

