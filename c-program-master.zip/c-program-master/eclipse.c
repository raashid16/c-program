#include<stdio.h>
float main()
{
float l,b,a;
printf(" Enter the length");
scanf("%f", &l);
printf(" Enter the breadth");
scanf("%f", &b);
a=3.14*l*b;
printf(" The area of the eclipse is %f " ,a);
} 
