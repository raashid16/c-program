#include<stdio.h>
int main()
{
int a,b,c,d,e,f;
printf(" Enter the value of a and b");
scanf("%d %d", &a,&b);
c = a+b;
d = a-b;
e = a*b;
f = a%b;
printf(" the sum is  %d ",c);
printf(" the diffrence is  %d ",d);
printf(" the product is  %d ",c);
printf(" the modulus is  %d ",c);
}
