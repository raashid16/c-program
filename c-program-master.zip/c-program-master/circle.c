#include<stdio.h>
float main()
{
float r,a;
printf(" Enter the radius");
scanf("%f", &r);
a= 3.14*r*r;
printf(" the area of the circle %f ",a);
} 
