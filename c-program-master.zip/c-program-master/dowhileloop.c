#include<stdio.h>
void main()
{
int counter=1;
do
{
printf("hello\n");
counter++;
}
while(counter<=0);
}	
