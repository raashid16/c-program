#include<stdio.h>
float main()
{
float a,b,c;
printf(" Enter a number A ");
scanf("%f", &a);
printf(" Enter a number B ");
scanf("%f", &b);
c = a/b;
printf("The  result c  after  the division of a and b is =%.2f \n", c);
}  

