#include<stdio.h>
#include<stdbool.h>
int main()
{
int counter=1;
while(true) 
{
printf("%d\n",counter);
counter++;
break;
}
printf("Empty");
}
