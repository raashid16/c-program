#include<stdio.h>
float main()
{
float r,a;
printf(" enter the radius ")
scanf("%f", &r);
a= 0.5*r*r* 
